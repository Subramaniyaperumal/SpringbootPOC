package com.springboot.poc;


import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EmployeeService {

	final EmployeeAssembler assembler = EmployeeAssembler.getInstance();
	
	@GET
    @RequestMapping("/employee/{empid}")
    @Produces("text/json")
    public Object getEmployee(@PathVariable("empid") String empid){
    	
		//System.out.println("EmployeeService.getEmployee()"+empid);
		//Response res  = Response.ok().build();
		Employee employee = assembler.getEmployee(empid);

		if( employee!=null){

			return employee;
		}
		
		return empid+ " -Invalid Employee Id"; 
		
	}
    
    
}

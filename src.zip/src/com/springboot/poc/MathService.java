package com.springboot.poc;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MathService {
	
	
	
    @RequestMapping("/add")
    public int add(@RequestParam("a") int a,@RequestParam("b") int b) {
    	System.out.println("HelloController.add()");
        return a+b;
    }
    
}

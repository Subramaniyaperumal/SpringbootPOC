package com.springboot.poc;

import java.util.HashMap;
import java.util.Map;

public class EmployeeAssembler {

	public static Map<String,Employee> employeeMap = new HashMap<String,Employee>();

	
	private static final EmployeeAssembler employeeAssembler = null;
	
	private EmployeeAssembler(){
		
		Employee employee1 = new Employee();
		employee1.setId("100");
		employee1.setDesignation("ITA");
		employee1.setName("subram");
		employeeMap.put(employee1.getId(),employee1);
		
		Employee employee2 = new Employee();
		employee2.setId("200");
		employee2.setDesignation("Developer");
		employee2.setName("Anand");
		employeeMap.put(employee2.getId(),employee2);
		
		Employee employee3 = new Employee();
		employee3.setId("300");
		employee3.setDesignation("Manager");
		employee3.setName("Sankar");
		employeeMap.put(employee3.getId(),employee3);

	}
	
	public static synchronized EmployeeAssembler getInstance(){
		if(employeeAssembler!=null){
			return employeeAssembler;
		}
		
		return new EmployeeAssembler();
	}
	
	public Employee getEmployee( String empId){
		
			
		return employeeMap.get(empId);
	}
}
